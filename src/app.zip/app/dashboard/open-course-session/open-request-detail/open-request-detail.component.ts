import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-open-request-detail',
  templateUrl: './open-request-detail.component.html',
  styleUrls: ['./open-request-detail.component.scss']
})
export class OpenRequestDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
