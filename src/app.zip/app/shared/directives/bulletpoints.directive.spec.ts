import { BulletpointsDirective } from './bulletpoints.directive';

describe('BulletpointsDirective', () => {
  it('should create an instance', () => {
    const directive = new BulletpointsDirective();
    expect(directive).toBeTruthy();
  });
});
